<?php
// +----------------------------------------------------------------------
// | OneThink [ WE CAN DO IT JUST THINK IT ]
// +----------------------------------------------------------------------
// | Copyright (c) 2013 http://www.onethink.cn All rights reserved.
// +----------------------------------------------------------------------
// | Author: 麦当苗儿 <zuojiazi@vip.qq.com> <http://www.zjzit.cn>
// +----------------------------------------------------------------------

namespace Admin\Controller;
use User\Api\UserApi as UserApi;

/**
 * 后台首页控制器
 * @author 麦当苗儿 <zuojiazi@vip.qq.com>
 */
class IndexController extends AdminController {

    static protected $allow = array( 'verify');

    /**
     * 后台首页
     * @author 麦当苗儿 <zuojiazi@vip.qq.com>
     */
    public function index(){
        if(UID){

          /*登录加载首页后判断项目中新增的项目或者进行中的项目
          一周之内是否有跟踪记录录入
          如果没有则邮件通知相应人员
          */
          /*首先拉去新增和进行中的项目*/
          $status = array('0','1');
          $map['status'] = array('in',$status);
          $projects = M('cst_cti_project as pr')
                        ->field('pr.id,pr.project_name,pr.last_time')
                        ->where($map)
                        ->select();
          // var_dump($projects);
          $tt = time();
          foreach ($projects as $key => $value) {
              $dd['last_time'] = $tt;
              $mm['id'] = $value['id'];
              // var_dump($dd);
              if($value['last_time'] +60*60*24*7 <time()){
                  // M('cst_cti_project')->where($mm)->save($dd);
                  $map2['pt.project_id'] = $value['id'];
                  $res2 = M('cst_cti_project_tail as pt') ->field('pt.follow_up_time') ->where($map2) ->order('pt.follow_up_time desc')->find();
                  if(!$res2){
                    $data['nofl'][$key] =  $value['project_name'];
                  }else{
                    $follow_up_time = strtotime($res2['follow_up_time']);
                    if($follow_up_time+60*60*24*7<time()){
                      $data['nolog'][$key] =  $value['project_name'];
                    }
                  }
              }
          }
          if(!$data){

          }else{
            $num1 = count($data['nofl']);
            $num2 = count($data['nolog']);
            $content = implode("<br/>", $data['nofl']);
            // var_dump($content);
            $content1 = implode("<br/>", $data['nolog']);
            // var_dump($content1);
            $cc = '未有跟进记录的项目('.$num1.'个):'. "<br/><br/>" .$content . "<br/><br/><br/>" .'超过七天没有跟进的项目('.$num2.'个):'. "<br/><br/>" .$content1;
            // var_dump($cc);
            // die();
            $ml = "huzangdan@gdwstech.com";
            SendMail2($ml,'OA系统项目跟踪提醒',$cc);
          }
          // die();
            $this->display();
        } else {
            $this->redirect('Public/login');
        }
    }

    /*首页加载读取账号权限*/
    public function getAuth(){

      $map['uid'] = UID;
      $auth = M("auth_group_access") ->field('group_id') ->where($map)->find();
      // $this->ajaxReturn($auth);
      if(UID == '1' || $auth['group_id'] =='13' || $auth['group_id'] =='15'||$auth['group_id'] =='19'){
        $data['status'] = 0;

        /*销售看板*/
          /*获取跟踪项目*/
          $start_time = date("Y",time());
          $start = $start_time.'-01-01 00:00:00';
          $end = date("Y-m-d",time());
          
          $end = $end.' 23:59:59';
          $map['create_time'] = array('between',array($start,$end),'AND');

          $dd[] = '0';
          $dd[] = '1';
          $map['status'] = array('in',$dd);
          $data['sale']['scount'] = M('cst_cti_project')->where($map)->count();
          // $sql = M()->getLastSql();
          // $data['sale']['sql'] = $sql;
          /*获取当年销售额*/
          $start_time = date("Y",time());
          $start = $start_time.'-01-01 00:00:00';
          $end = date("Y-m-d",time()+60*60*24);
          $end = $end.' 23:59:59';
          $map1['start_time'] = array('between',array($start,$end),'AND');
          $map1['status'] = '3';
          $price = M('cst_contract') ->where($map1)->sum('contract_fee');
          // $data['sale']['price'] = M()->getLastSql;
          $data['sale']['price'] = number_format ($price , 2 , '.' , ',' );
          if(!$price){
            $data['sale']['price'] = '0';
          }

          

          /*获取当年回款金额*/
          $map2['wi.create_time'] = array('between',array($start,$end),'AND');
          $map2['wi.status'] = '2';
          $rprice1 = M('cst_fd_withdraw as wi') 
                      ->join('left join oa_cst_pj_plan_phases as ph on ph.project_id = wi.project_id and wi.phases = ph.phases')
                      ->where($map2)
                      ->sum('PhasesFee');

          $kkk['wi.create_time'] = array('between',array($start,$end),'AND');
          $kkk['wi.status'] = '2';
          $kkk['wi.plan_code'] = array('EXP','IS NULL');
          $rprice2 = M('cst_fd_withdraw as wi') 
                      ->join('left join oa_cst_contract as con on con.contract_code = wi.contract_code')
                      ->where($kkk)
                      ->sum('contract_fee');
          $rprice = $rprice1+$rprice2;

          $data['sale']['rprice'] = number_format ($rprice , 2 , '.' , ',' );
          if(!$rprice){
            $data['sale']['rprice'] = '0';
          }

          $pageindex = $_GET["p"];
          if (empty($pageindex)||$pageindex=="0") {
              $pageindex=1;
          }
          $pagesize = PAGESIZE;

          /*获取跟踪记录*/
          $map3['pr.status'] = array('in',$dd);
          $gz = M('cst_cti_project as pr') 
                      ->field('pr.project_name,pr.province,pr.budget,cu.customer,pr.charge_person,pr.purchase_intention')
                      ->join('left join oa_cst_customer as cu on pr.customer = cu.id')
                      ->join('left join oa_member as me on me.uid = pr.charge_person')
                      ->where($map3)
                      ->page($pageindex, $pagesize)
                      ->select();

          if(!$gz){
            $data['sale']['gz']['content'] = array();
            $data['sale']['gz']['count'] = '0';
          }else{
            foreach ($gz as $key6 => $value6) {
              $gz[$key6]['budget'] = number_format ($value6['budget'] , 2 , '.' , ',' );
            }
            $data['sale']['gz']['content'] = $gz;
            $data['sale']['gz']['count'] = $data['sale']['scount'];
            
          }

          /*获取折线图数据*/
          $num = intval(date("m",time()));
          for($i=1;$i<=$num;$i++){
            $m = sprintf("%02d", $i);
            $m1 = sprintf("%02d", $i+1);
            // $data['ze'][$i] = $i;
            $y = date("Y",time());
            $ss = $y.'-01-01 00:00:00';
            $dd = $y.'-'.$m1.'-01 00:00:00';

            /*累计销售额*/
            $map4['start_time'] = array('between',array($ss,$dd),'AND');
            $map4['status'] = '3';
            $price4 = M('cst_contract') ->where($map4)->sum('contract_fee');
            if(!$price4){
              $data['sale']['ze'][] = '0';
            }else{
              $data['sale']['ze'][] = $price4;
            }

            /*累计回款额*/
            $map5['wi.create_time'] = array('between',array($ss,$dd),'AND');
            $rp1 = M('cst_fd_withdraw as wi') 
                        ->join('left join oa_cst_pj_plan_phases as ph on ph.project_id = wi.project_id and wi.phases = ph.phases')
                        ->where($map5)
                        ->sum('PhasesFee');

            $kkk1['wi.create_time'] = array('between',array($ss,$dd),'AND');
            $kkk1['wi.status'] = '2';
            $kkk1['wi.plan_code'] = array('EXP','IS NULL');
            $rp2 = M('cst_fd_withdraw as wi') 
                        ->join('left join oa_cst_contract as con on con.contract_code = wi.contract_code')
                        ->where($kkk1)
                        ->sum('contract_fee');
            $rp[$i] = $rp1+$rp2;

            if(!$rp){
              $data['sale']['ze1'][] = '0';
            }else{
              $data['sale']['ze1'][] = $rp[$i];
            }
            $data['sale']['month'][] = $i."月";   

          }

        /*实施看板*/
          /*正在实施项目*/
          $tmap['pl.create_time'] = array('between',array($start,$end),'AND');
          $tmap['pl.status'] = '1';
          $data['tech']['tcout'] = M('cst_pj_plan as pl')
                        ->where($tmap)
                        ->count();
          $data['tech']['sql'] = M()->getLastSql();          
          $data['tech']['phases']['content'] = M('cst_pj_plan_phases as ph') 
                                    ->field('pr.project_name,ph.phases,ph.products,me.nickname as executor,ph.PhasesFee')
                                    ->join('left join oa_cst_pj_plan as pl on pl.project_id = ph.project_id')
                                    ->join('left join oa_cst_cti_project as pr on ph.project_id = pr.id')
                                    ->join('left join oa_member as me on ph.executor = me.uid')
                                    ->where($tmap)
                                    ->select();
          $data['tech']['phases']['pcount'] = M('cst_pj_plan_phases as ph')
                                    ->join('left join oa_cst_pj_plan as pl on pl.project_id = ph.project_id')
                                    ->join('left join oa_cst_cti_project as pr on ph.project_id = pr.id')
                                    ->join('left join oa_member as me on ph.executor = me.uid')
                                    ->where($tmap)
                                    ->count();

          if(!$data['tech']['phases']['content']){
            $data['tech']['phases']['content'] = array(); 
          }
          if(!$data['tech']['phases']['pcount']){
            $data['tech']['phases']['pcount'] = '0'; 
          }                          

          /*获取实施回款金额*/
          $rmap['rd.create_time'] = array('between',array($start,$end),'AND');
          $rmap['rd.status'] = '2';
          $data['tech']['rmoney'] = M('cst_pj_payreminder_rd as rd') ->where($rmap)->sum('rmoney');
          $data['tech']['rmoney'] = number_format ($data['tech']['rmoney'], 2 , '.' , ',' );
          if(!$data['tech']['rmoney']){
            $data['tech']['rmoney'] = '0';
          }

          /*获取实施催款金额*/
          $rmap['rd.create_time'] = array('between',array($start,$end),'AND');
          $rmap['rd.status'] = array('in','0,1');
          $data['tech']['cmoney'] = M('cst_pj_payreminder_rd as rd') ->where($rmap)->sum('rmoney');
          $data['tech']['cmoney'] = number_format ($data['tech']['cmoney'], 2 , '.' , ',' );

          /*获取正在收款项目*/
          $rmap['rd.create_time'] = array('between',array($start,$end),'AND');
          $rmap['rd.status'] = array('in','0,1');
          $data['tech']['ckproject']['content'] = M('cst_pj_payreminder_rd as rd') 
                                                      ->field('pr.project_name,rd.phases,rd.status,rd.rmoney,rd.prompt_result,rd.rpercent,rd.prompt_id,me.nickname as executor')
                                                      ->join('oa_cst_cti_project as pr on pr.id = rd.project_id')
                                                      ->join('left join oa_member as me on rd.executor = me.uid')
                                                      ->where($rmap)
                                                      ->select();

          $data['tech']['ckproject']['ckcount'] = M('cst_pj_payreminder_rd as rd') 
                                                      ->field('pr.project_name,rd.phases,rd.status,rd.rmoney')
                                                      ->join('oa_cst_cti_project as pr on pr.id = rd.project_id')
                                                      ->where($rmap)
                                                      ->count();    

          if(!$data['tech']['ckproject']['content']){
            $data['tech']['ckproject']['content'] = array(); 
          }
          if(!$data['tech']['ckproject']['ckcount']){
            $data['tech']['ckproject']['ckcount'] = '0'; 
          }                                                   

          /*柱状图项目跟踪费用和人天*/      
          $num = intval(date("m",time()));
          for($j1=1;$j1<=$num;$j1++){
            $jj1 = sprintf("%02d", $j1);
            $jj1 = sprintf("%02d", $j1+1);
            // $data['ze'][$i] = $i;
            $y1 = date("Y",time());
            $sss1 = $y1.'-01-01 00:00:00';
            $dds1 = $y1.'-'.$jj1.'-01 00:00:00';

            /*累计销售额*/
            $map81['rd.rd_time'] = array('between',array($sss1,$dds1),'AND');
            $manday1 = M('cst_pj_excute_rd as rd') 
                            ->field('rd.project_id,pr.project_name,rd.phases,rd.products,rd.project_fee,rd.content,rd.executor,rd.manday')
                            ->join('left join oa_cst_cti_project as pr on rd.project_id = pr.id')
                            // ->join('left join oa_member as me on rd.executor = me.uid')
                            ->where($map81)
                            ->select();
           
            $data['tech']['manday']['content'] = $manday1;
            $data['tech']['manday']['count'] = M('cst_pj_excute_rd as rd') 
                                            ->field('rd.project_id,pr.project_name,rd.phases,rd.products,rd.project_fee,rd.content,rd.executor,rd.manday')
                                            ->join('left join oa_cst_cti_project as pr on rd.project_id = pr.id')
                                            // ->join('left join oa_member as me on rd.executor = me.uid')
                                            ->where($map81)
                                            ->count();

            if(!$data['tech']['manday']['content']){
              $data['tech']['manday']['content'] = array(); 
            }
            if(!$data['tech']['manday']['count']){
              $data['tech']['manday']['count'] = '0'; 
            }      
            
            
          } 

        /*售后看板*/
          /*获取已收款的项目或项目阶段*/
          /*财务确认*/
          $mm['wi.status'] = '2';
          $service = M('cst_fd_withdraw as wi')
                                          ->field('wi.updata_time,pr.project_name,wi.phases,ph.etime,ph.products,ph.PhasesFee,wi.create_time')
                                          ->join('left join oa_cst_cti_project as pr on wi.project_id = pr.id')
                                          ->join('left join oa_cst_pj_plan_phases as ph on wi.project_id = ph.project_id and wi.phases = ph.phases')
                                          ->where($mm) 
                                          ->page($pageindex, $pagesize)
                                          ->select();  
          $ccc = M('cst_fd_withdraw as wi')
                                          // ->field('wi.updata_time,pr.project_name,wi.phases,ph.etime,ph.products,ph.PhasesFee')
                                          ->join('left join oa_cst_cti_project as pr on wi.project_id = pr.id')
                                          ->join('left join oa_cst_pj_plan_phases as ph on wi.project_id = ph.project_id and wi.phases = ph.phases')
                                          ->where($mm) 
                                          ->count();  
          if(!$gz){
            $data['after']['content'] = array(); 
            $data['after']['count'] = '0';
          }else{
            $data['after']['content'] = $service; 
            $data['after']['count'] = $ccc;
            
          }
          
        /*开发看板*/
          /*获取正在开发新产品数目*/
          $ndmap['status'] = '1';
          $newdevnum = M('cst_dev_newproduct')->where($ndmap)->count();  
          $data['dev']['dcount'] = $newdevnum; 
          
          /*获取正在开发定制产品数目*/
          $ndmap['status'] = '2';
          $newdevnum1 = M('cst_dev_customization')->where($ndmap)->count();  
          $data['dev']['ccount'] = $newdevnum1;  

           /*获取定制开发人天*/
          $ndmap['status'] = '2';
          $cusmanday = M('cst_dev_customization')->where($ndmap)->sum('manday');  
          $data['dev']['cusmanday'] = $cusmanday;  
          if(!$cusmanday){
            $data['dev']['cusmanday'] = '0';  
          }

          /*获取已到期开发阶段*/
          $pmap['cu.status'] = '2';
          $pmap['ph.etime'] = array('elt',date("Y-m-d h:m:s",time()));
          $devphases = M('cst_cus_dev_phases as ph') 
                             ->field('ph.etime,ph.products,pr.project_name,ph.phases,ph.PhasesFee,me.nickname as dev_role') 
                             ->join('left join oa_cst_dev_customization as cu on cu.plan_code = ph.plan_code') 
                             ->join('left join oa_cst_cti_project as pr on cu.project_id = pr.id') 
                             ->join('left join oa_member as me on me.uid = cu.dev_role') 
                             ->where($pmap) 
                             ->select();
          // $data['dev']['sql'] = M()->getLastSql();
          $devcount = M('cst_cus_dev_phases as ph') 
                             // ->field('') 
                             ->join('left join oa_cst_dev_customization as cu on cu.plan_code = ph.plan_code') 
                             ->join('left join oa_cst_cti_project as pr on cu.project_id = pr.id') 
                             ->join('left join oa_member as me on me.uid = ph.coder') 
                             ->where($pmap) 
                             // ->select();
                             ->count();
          if(!$devphases){
            $data['dev']['devphases']['content'] = array();
            $data['dev']['devphases']['count'] = '0';
          }else{
            $data['dev']['devphases']['content'] = $devphases;                     
            $data['dev']['devphases']['count'] = $devcount;                     
          }

          /*获取开发交付记录*/
          $num = intval(date("m",time()));
          $jj1 = sprintf("%02d", $num+1);
          $y = date("Y",time());
          $sss1 = $y.'-01-01 00:00:00';
          $dds1 = $y.'-'.$jj1.'-01 00:00:00';
          $dtmap['de.del_date'] = array('between',array($sss1,$dds1),'AND');
          $data['dev']['delivery']['content'] = M('cst_dev_delivery as de')
                                                      ->field('de.delivery_code,de.delivery_type,pr.project_name,de.del_date,de.deliver_product,de.dev_role,de.tech_role,cus.eEnd_time,cus.End_time,cus.Need_time')
                                                      ->join('left join oa_cst_cti_project as pr on pr.id = de.project_id')
                                                      ->join('left join oa_cst_dev_customization as cus on de.contract_code and de.project_id = cus.project_id')
                                                      ->where($dtmap)
                                                      ->order('del_date desc')
                                                      ->page(1,10)
                                                      ->select(); 
          foreach ($data['dev']['delivery']['content'] as $keyd => $valued) {
              if($valued['delivery_type'] == '1'){
                $data['dev']['delivery']['content'][$keyd]['delivery_type'] = '需求新增';
              }elseif ($valued['delivery_type'] == '2') {
                $data['dev']['delivery']['content'][$keyd]['delivery_type'] = 'bug修复';
              }elseif ($valued['delivery_type'] == '3') {
                $data['dev']['delivery']['content'][$keyd]['delivery_type'] = '首次交付';
              }
          }    

          $data['dev']['delivery']['count'] = M('cst_dev_delivery as de')
                                                      ->field('de.delivery_code,pr.project_name,de.del_date,de.deliver_product,de.dev_role,de.tech_role')
                                                      ->join('left join oa_cst_cti_project as pr on pr.id = de.project_id')
                                                      ->where($dtmap)
                                                      ->count();  

          if(!$data['dev']['delivery']['content']){
            $data['dev']['delivery']['content'] = array();
            
          }
          if(!$data['dev']['delivery']['count']){
            $data['dev']['delivery']['count'] = '0';
            
          }
          /*交付情况对比*/
            /*获取超时交付项目数目*/
            $exNum = M('cst_dev_customization')
                                  // ->join('left join oa_cst_dev_customization as cu on cu.project_id = de.project_id')
                                  ->where('End_time < eEnd_time')
                                  ->count();
            $data['dev']['circle']['exNum'] = $exNum;
            
            /*获取提前交付项目数目*/
            $aheadNum = M('cst_dev_customization')
                                  ->where('End_time < eEnd_time')
                                  ->count();
            $data['dev']['circle']['aheadNum'] = $aheadNum;

            /*获取按时交付项目数目*/
            $Num = M('cst_dev_customization')
                                  ->where('End_time = eEnd_time')
                                  ->count();
            $data['dev']['circle']['Num'] = $Num;


        $this->ajaxReturn($data);

      }else if($auth['group_id'] =='4' || $auth['group_id'] =='7'){
        $data['status'] = 1;

        /*销售看板*/

          /*销售看板*/
          /*获取跟踪项目*/
          $start_time = date("Y",time());
          $start = $start_time.'-01-01 00:00:00';
          $end = date("Y-m-d",time());
          
          $end = $end.' 23:59:59';
          $map['create_time'] = array('between',array($start,$end),'AND');

          $dd[] = '0';
          $dd[] = '1';
          $map['status'] = array('in',$dd);
          $data['sale']['scount'] = M('cst_cti_project')->where($map)->count();
          // $sql = M()->getLastSql();
          // $data['sale']['sql'] = $sql;
          /*获取当年销售额*/
          $start_time = date("Y",time());
          $start = $start_time.'-01-01 00:00:00';
          $end = date("Y-m-d",time());
          $end = $end.' 23:59:59';
          $map1['start_time'] = array('between',array($start,$end),'AND');
          $map1['status'] = '3';
          $price = M('cst_contract') ->where($map1)->sum('contract_fee');
          // $data['sale']['price'] = $price;
          $data['sale']['price'] = number_format ($price , 2 , '.' , ',' );
          if(!$price){
            $data['sale']['price'] = '0';
          }

          /*获取当年回款金额*/
          $map2['wi.create_time'] = array('between',array($start,$end),'AND');
          $map2['wi.status'] = '2';
          $rprice1 = M('cst_fd_withdraw as wi') 
                      ->join('left join oa_cst_pj_plan_phases as ph on ph.project_id = wi.project_id and wi.phases = ph.phases')
                      ->where($map2)
                      ->sum('PhasesFee');
          $kkk['wi.create_time'] = array('between',array($start,$end),'AND');
          $kkk['wi.status'] = '2';
          $kkk['wi.plan_code'] = array('EXP','IS NULL');
          $rprice2 = M('cst_fd_withdraw as wi') 
                      ->join('left join oa_cst_contract as con on con.contract_code = wi.contract_code')
                      ->where($kkk)
                      ->sum('contract_fee');
          $rprice = $rprice1+$rprice2;
          $data['sale']['rprice'] = number_format ($rprice , 2 , '.' , ',' );
          if(!$rprice){
            $data['sale']['rprice'] = '0';
          }

          $pageindex = $_GET["p"];
          if (empty($pageindex)||$pageindex=="0") {
              $pageindex=1;
          }
          $pagesize = PAGESIZE;

          /*获取跟踪记录*/
          $map3['pr.status'] = array('in',$dd);
          $gz = M('cst_cti_project as pr') 
                      ->field('pr.project_name,pr.province,pr.budget,cu.customer,pr.charge_person,pr.purchase_intention')
                      ->join('left join oa_cst_customer as cu on pr.customer = cu.id')
                      ->join('left join oa_member as me on me.uid = pr.charge_person')
                      ->where($map3)
                      ->page($pageindex, $pagesize)
                      ->select();

          if(!$gz){
            $data['sale']['gz']['content'] = array();
            $data['sale']['gz']['count'] = '0';
          }else{
            foreach ($gz as $key6 => $value6) {
              $gz[$key6]['budget'] = number_format ($value6['budget'] , 2 , '.' , ',' );
            }
            $data['sale']['gz']['content'] = $gz;
            $data['sale']['gz']['count'] = $data['sale']['scount'];
            
          }

          /*获取折线图数据*/
          $num = intval(date("m",time()));
          for($i=1;$i<=$num;$i++){
            $m = sprintf("%02d", $i);
            $m1 = sprintf("%02d", $i+1);
            // $data['ze'][$i] = $i;
            $y = date("Y",time());
            $ss = $y.'-01-01 00:00:00';
            $dd = $y.'-'.$m1.'-01 00:00:00';

            /*累计销售额*/
            $map4['start_time'] = array('between',array($ss,$dd),'AND');
            $map4['status'] = '3';
            $price4 = M('cst_contract') ->where($map4)->sum('contract_fee');
            if(!$price4){
              $data['sale']['ze'][] = '0';
            }else{
              $data['sale']['ze'][] = $price4;
            }

          $map2['wi.create_time'] = array('between',array($start,$end),'AND');
          $map2['wi.status'] = '2';
          $rprice1 = M('cst_fd_withdraw as wi') 
                      ->join('left join oa_cst_pj_plan_phases as ph on ph.project_id = wi.project_id and wi.phases = ph.phases')
                      ->where($map2)
                      ->sum('PhasesFee');
          $kkk['wi.create_time'] = array('between',array($start,$end),'AND');
          $kkk['wi.status'] = '2';
          $kkk['wi.plan_code'] = array('EXP','IS NULL');
          $rprice2 = M('cst_fd_withdraw as wi') 
                      ->join('left join oa_cst_contract as con on con.contract_code = wi.contract_code')
                      ->where($kkk)
                      ->sum('contract_fee');
          $rprice = $rprice1+$rprice2;
          $data['sale']['rprice'] = number_format ($rprice , 2 , '.' , ',' );
          if(!$rprice){
            $data['sale']['rprice'] = '0';
          }

          /*累计回款额*/
          $map5['wi.create_time'] = array('between',array($ss,$dd),'AND');
          $rp1 = M('cst_fd_withdraw as wi') 
                      ->join('left join oa_cst_pj_plan_phases as ph on ph.project_id = wi.project_id and wi.phases = ph.phases')
                      ->where($map5)
                      ->sum('PhasesFee');

          $kkk1['wi.create_time'] = array('between',array($ss,$dd),'AND');
          $kkk1['wi.status'] = '2';
          $kkk1['wi.plan_code'] = array('EXP','IS NULL');
          $rp2 = M('cst_fd_withdraw as wi') 
                      ->join('left join oa_cst_contract as con on con.contract_code = wi.contract_code')
                      ->where($kkk1)
                      ->sum('contract_fee');
          $rp[$i] = $rp1+$rp2;
          if(!$rp){
            $data['sale']['ze1'][] = '0';
          }else{
            $data['sale']['ze1'][] = $rp[$i];
          }
          $data['sale']['month'][] = $i."月";   

          }

        $this->ajaxReturn($data);
      }else if($auth['group_id'] =='17' || $auth['group_id'] =='14'){
        /*售后看板*/
        $data['status'] = 2;
        /*售后看板*/
          /*售后看板*/
          /*获取已收款的项目或项目阶段*/
          /*财务确认*/
          $mm['wi.status'] = '2';
          $service = M('cst_fd_withdraw as wi')
                                          ->field('wi.updata_time,pr.project_name,wi.phases,ph.etime,ph.products,ph.PhasesFee,wi.create_time')
                                          ->join('left join oa_cst_cti_project as pr on wi.project_id = pr.id')
                                          ->join('left join oa_cst_pj_plan_phases as ph on wi.project_id = ph.project_id and wi.phases = ph.phases')
                                          ->where($mm) 
                                          ->page($pageindex, $pagesize)
                                          ->select();  
          $ccc = M('cst_fd_withdraw as wi')
                                          // ->field('wi.updata_time,pr.project_name,wi.phases,ph.etime,ph.products,ph.PhasesFee')
                                          ->join('left join oa_cst_cti_project as pr on wi.project_id = pr.id')
                                          ->join('left join oa_cst_pj_plan_phases as ph on wi.project_id = ph.project_id and wi.phases = ph.phases')
                                          ->where($mm) 
                                          ->count();
          if(!$gz){
            $data['after']['content'] = array(); 
            $data['after']['count'] = '0';
          }else{
            $data['after']['content'] = $service; 
            $data['after']['count'] = $ccc;
            
          }


        $this->ajaxReturn($data);
      }else if($auth['group_id'] =='3' || $auth['group_id'] =='9'|| $auth['group_id'] =='18'){
        /*实施看板*/
        $data['status'] = 3;
        /*实施看板*/
          /*正在实施项目*/
          $start_time = date("Y",time());
          $start = $start_time.'-01-01 00:00:00';
          $end = date("Y-m-d h:m:s",time()+60*60*24);
          $tmap['pl.create_time'] = array('between',array($start,$end),'AND');
          $tmap['pl.status'] = '1';
          $data['tech']['tcout'] = M('cst_pj_plan as pl')
                        ->where($tmap)
                        ->count();
          $data['tech']['phases']['content'] = M('cst_pj_plan_phases as ph') 
                                    ->field('pr.project_name,ph.phases,ph.products,me.nickname as executor,ph.PhasesFee')
                                    ->join('left join oa_cst_pj_plan as pl on pl.project_id = ph.project_id')
                                    ->join('left join oa_cst_cti_project as pr on ph.project_id = pr.id')
                                    ->join('left join oa_member as me on ph.executor = me.uid')
                                    ->where($tmap)
                                    ->select();

          // $data['tech']['sql'] = M()->getLastSql();
          $data['tech']['phases']['pcount'] = M('cst_pj_plan_phases as ph')
                                    ->join('left join oa_cst_pj_plan as pl on pl.project_id = ph.project_id')
                                    ->join('left join oa_cst_cti_project as pr on ph.project_id = pr.id')
                                    ->join('left join oa_member as me on ph.executor = me.uid')
                                    ->where($tmap)
                                    ->count();
          if(!$data['tech']['phases']['content']){
            $data['tech']['phases']['content'] = array(); 
          }
          if(!$data['tech']['phases']['pcount']){
            $data['tech']['phases']['pcount'] = '0'; 
          }

          /*获取实施回款金额*/
          $rmap['rd.create_time'] = array('between',array($start,$end),'AND');
          $rmap['rd.status'] = '2';
          $data['tech']['rmoney'] = M('cst_pj_payreminder_rd as rd') ->where($rmap)->sum('rmoney');
          $data['tech']['rmoney'] = number_format ($data['tech']['rmoney'], 2 , '.' , ',' );
          if(!$data['tech']['rmoney']){
            $data['tech']['rmoney'] = '0';
          }

          /*获取实施催款金额*/
          $rmap['rd.create_time'] = array('between',array($start,$end),'AND');
          $rmap['rd.status'] = array('in','0,1');
          $data['tech']['cmoney'] = M('cst_pj_payreminder_rd as rd') ->where($rmap)->sum('rmoney');
          $data['tech']['cmoney'] = number_format ($data['tech']['cmoney'], 2 , '.' , ',' );

          /*获取正在收款项目*/
          $rmap['rd.create_time'] = array('between',array($start,$end),'AND');
          $rmap['rd.status'] = array('in','0,1');
          $data['tech']['ckproject']['content'] = M('cst_pj_payreminder_rd as rd') 
                                                      ->field('pr.project_name,rd.phases,rd.status,rd.rmoney,rd.prompt_result,rd.rpercent,rd.prompt_id,me.nickname as executor')
                                                      ->join('oa_cst_cti_project as pr on pr.id = rd.project_id')
                                                      ->join('left join oa_member as me on rd.executor = me.uid')
                                                      ->where($rmap)
                                                      ->select();

          $data['tech']['ckproject']['ckcount'] = M('cst_pj_payreminder_rd as rd') 
                                                      ->field('pr.project_name,rd.phases,rd.status,rd.rmoney')
                                                      ->join('oa_cst_cti_project as pr on pr.id = rd.project_id')
                                                      ->where($rmap)
                                                      ->count();

          if(!$data['tech']['ckproject']['content']){
            $data['tech']['ckproject']['content'] = array(); 
          }
          if(!$data['tech']['ckproject']['ckcount']){
            $data['tech']['ckproject']['ckcount'] = '0'; 
          }                                           
                                                                                            
          /*柱状图项目跟踪费用和人天*/      
          $num = intval(date("m",time()));
          for($j1=1;$j1<=$num;$j1++){
            $jj1 = sprintf("%02d", $j1);
            $jj1 = sprintf("%02d", $j1+1);
            // $data['ze'][$i] = $i;
            $y1 = date("Y",time());
            $sss1 = $y1.'-01-01 00:00:00';
            $dds1 = $y1.'-'.$jj1.'-01 00:00:00';

            /*累计销售额*/
            $map81['rd.rd_time'] = array('between',array($sss1,$dds1),'AND');
            $manday1 = M('cst_pj_excute_rd as rd') 
                            ->field('rd.project_id,pr.project_name,rd.phases,rd.products,rd.project_fee,rd.content,rd.executor,rd.manday')
                            ->join('left join oa_cst_cti_project as pr on rd.project_id = pr.id')
                            // ->join('left join oa_member as me on rd.executor = me.uid')
                            ->where($map81)
                            ->select();
           
            $data['tech']['manday']['content'] = $manday1;
            $data['tech']['manday']['count'] = M('cst_pj_excute_rd as rd') 
                                            ->field('rd.project_id,pr.project_name,rd.phases,rd.products,rd.project_fee,rd.content,rd.executor,rd.manday')
                                            ->join('left join oa_cst_cti_project as pr on rd.project_id = pr.id')
                                            // ->join('left join oa_member as me on rd.executor = me.uid')
                                            ->where($map81)
                                            ->count();
            if(!$data['tech']['manday']['content']){
              $data['tech']['manday']['content'] = array(); 
            }
            if(!$data['tech']['manday']['count']){
              $data['tech']['manday']['count'] = '0'; 
            }      
              
          } 
        $this->ajaxReturn($data);  
      }else if($auth['group_id'] =='8' || $auth['group_id'] =='9' || $auth['group_id'] =='10'){
      
        /*开发看板*/
        $data['status'] = 4;
          /*开发看板*/
          /*获取正在开发新产品数目*/
          $ndmap['status'] = '1';
          $newdevnum = M('cst_dev_newproduct')->where($ndmap)->count();  
          $data['dev']['dcount'] = $newdevnum; 
          
          /*获取正在开发定制产品数目*/
          $ndmap['status'] = '2';
          $newdevnum1 = M('cst_dev_customization')->where($ndmap)->count();  
          $data['dev']['ccount'] = $newdevnum1;  

           /*获取定制开发人天*/
          $ndmap['status'] = '2';
          $cusmanday = M('cst_dev_customization')->where($ndmap)->sum('manday');  
          $data['dev']['cusmanday'] = $cusmanday;  
          if(!$cusmanday){
            $data['dev']['cusmanday'] = '0';  
          }

          /*获取已到期开发阶段*/
          $pmap['cu.status'] = '2';
          $pmap['ph.etime'] = array('elt',date("Y-m-d h:m:s",time()));
          $devphases = M('cst_cus_dev_phases as ph') 
                             ->field('ph.etime,ph.products,pr.project_name,ph.phases,ph.PhasesFee,me.nickname as dev_role') 
                             ->join('left join oa_cst_dev_customization as cu on cu.plan_code = ph.plan_code') 
                             ->join('left join oa_cst_cti_project as pr on cu.project_id = pr.id') 
                             ->join('left join oa_member as me on me.uid = cu.dev_role') 
                             ->where($pmap) 
                             ->select();
          // $data['dev']['sql'] = M()->getLastSql();
          $devcount = M('cst_cus_dev_phases as ph') 
                             // ->field('') 
                             ->join('left join oa_cst_dev_customization as cu on cu.plan_code = ph.plan_code') 
                             ->join('left join oa_cst_cti_project as pr on cu.project_id = pr.id') 
                             ->join('left join oa_member as me on me.uid = ph.coder') 
                             ->where($pmap) 
                             // ->select();
                             ->count();
          if(!$devphases){
            $data['dev']['devphases']['content'] = array();
            $data['dev']['devphases']['count'] = '0';
          }else{
            $data['dev']['devphases']['content'] = $devphases;                     
            $data['dev']['devphases']['count'] = $devcount;                     
          }

          /*获取开发交付记录*/
          $num = intval(date("m",time()));
          $jj1 = sprintf("%02d", $num+1);
          $y = date("Y",time());
          $sss1 = $y.'-01-01 00:00:00';
          $dds1 = $y.'-'.$jj1.'-01 00:00:00';
          $dtmap['de.del_date'] = array('between',array($sss1,$dds1),'AND');
          $data['dev']['delivery']['content'] = M('cst_dev_delivery as de')
                                                      ->field('de.delivery_code,de.delivery_type,pr.project_name,de.del_date,de.deliver_product,de.dev_role,de.tech_role,cus.eEnd_time,cus.End_time,cus.Need_time')
                                                      ->join('left join oa_cst_cti_project as pr on pr.id = de.project_id')
                                                      ->join('left join oa_cst_dev_customization as cus on de.contract_code and de.project_id = cus.project_id')
                                                      ->where($dtmap)
                                                      ->order('del_date desc')
                                                      ->page(1, 10)
                                                      ->select();
          foreach ($data['dev']['delivery']['content'] as $keyd => $valued) {
              if($valued['delivery_type'] == '1'){
                $data['dev']['delivery']['content'][$keyd]['delivery_type'] = '需求新增';
              }elseif ($valued['delivery_type'] == '2') {
                $data['dev']['delivery']['content'][$keyd]['delivery_type'] = 'bug修复';
              }elseif ($valued['delivery_type'] == '3') {
                $data['dev']['delivery']['content'][$keyd]['delivery_type'] = '首次交付';
              }
          }  
          $data['dev']['delivery']['count'] = M('cst_dev_delivery as de')
                                                      ->field('de.delivery_code,pr.project_name,de.del_date,de.deliver_product,de.dev_role,de.tech_role')
                                                      ->join('left join oa_cst_cti_project as pr on pr.id = de.project_id')
                                                      ->join('left join oa_cst_dev_customization as cus on de.contract_code and de.project_id = cus.project_id')
                                                      ->where($dtmap)
                                                      ->count();  

          if(!$data['dev']['delivery']['content']){
            $data['dev']['delivery']['content'] = array();
            
          }
          if(!$data['dev']['delivery']['count']){
            $data['dev']['delivery']['count'] = '0';
            
          }

          /*交付情况对比*/
            /*获取超时交付项目数目*/
            $exNum = M('cst_dev_delivery as de')
                                  ->join('left join oa_cst_dev_customization as cu on cu.project_id = de.project_id')
                                  ->where('de.del_date > cu.eEnd_time')
                                  ->count();
            $data['dev']['circle']['exNum'] = $exNum;
            
            /*获取提前交付项目数目*/
            $aheadNum = M('cst_dev_delivery as de')
                                  ->join('left join oa_cst_dev_customization as cu on cu.project_id = de.project_id')
                                  ->where('de.del_date < cu.eEnd_time')
                                  ->count();
            $data['dev']['circle']['aheadNum'] = $aheadNum;

            /*获取按时交付项目数目*/
            $Num = M('cst_dev_delivery as de')
                                  ->join('left join oa_cst_dev_customization as cu on cu.project_id = de.project_id')
                                  ->where('de.del_date = cu.eEnd_time')
                                  ->count();
            $data['dev']['circle']['Num'] = $Num;

        $this->ajaxReturn($data);
      }
  
      
    }


    /*售后面板Ajax搜索*/
    public function ajaxAfter(){
          /*获取已收款的项目或项目阶段*/
          /*财务确认*/
          if(I('project_name')){
            $mm['pr.project_name'] = array('like', '%' . (string)I('project_name') . '%');
          }

          $pageindex = I('page');
          if (empty($pageindex)||$pageindex=="0") {
              $pageindex['p']=1;
          }
          $pagesize = 5;
         
          $mm['wi.status'] = '2';
          $service = M('cst_fd_withdraw as wi')
                                          ->field('wi.updata_time,pr.project_name,wi.phases,ph.etime,ph.products,ph.PhasesFee')
                                          ->join('left join oa_cst_cti_project as pr on wi.project_id = pr.id')
                                          ->join('left join oa_cst_pj_plan_phases as ph on wi.project_id = ph.project_id and wi.phases = ph.phases')
                                          ->where($mm) 
                                          ->page($pageindex['p'], $pagesize)
                                          ->select();  
          $data['after']['content'] = $service;
          if(!$service){
            $data['after']['content'] = array();
          }
          $data['after']['count'] = M('cst_fd_withdraw as wi')
                                          ->field('wi.updata_time,pr.project_name,wi.phases,ph.etime,ph.products,ph.PhasesFee')
                                          ->join('left join oa_cst_cti_project as pr on wi.project_id = pr.id')
                                          ->join('left join oa_cst_pj_plan_phases as ph on wi.project_id = ph.project_id and wi.phases = ph.phases')
                                          ->where($mm) 
                                          ->page($pageindex['p'], $pagesize)
                                          ->count(); 
          $this ->ajaxReturn($data);
          
    }


    /*ajax分页*/
    public function getPageContent(){
      /*获取分页类型*/
      $type = $_GET["type"];
      /*获取页数*/
      $pageindex = $_GET["gzpage"];
      if (empty($pageindex)||$pageindex=="0") {
          $pageindex=1;
      }
      $pagesize = PAGESIZE;
      
      /*获取跟踪记录*/
      if($type == 1){
          $dd[] = '0';
          $dd[] = '1';
          

          /*获取跟踪记录*/
          $map3['pr.status'] = array('in',$dd);
          $gz = M('cst_cti_project as pr') 
                      ->field('pr.project_name,pr.province,pr.budget,cu.customer,pr.charge_person,pr.purchase_intention')
                      ->join('left join oa_cst_customer as cu on pr.customer = cu.id')
                      ->join('left join oa_member as me on me.uid = pr.charge_person')
                      ->where($map3)
                      ->page($pageindex, $pagesize)
                      ->select();
          foreach ($gz as $key6 => $value6) {
            $gz[$key6]['budget'] = number_format ($value6['budget'] , 2 , '.' , ',' );
          }
          // $this ->ajaxReturn(M()->getLastSql());
          $this ->ajaxReturn($gz);
      }elseif ($type == 2) {
        /*获取售后记录*/
        $mm['wi.status'] = '2';
        $service = M('cst_fd_withdraw as wi')
                      ->field('wi.updata_time,pr.project_name,wi.phases,ph.etime,ph.products,ph.PhasesFee,wi.create_time')
                      ->join('left join oa_cst_cti_project as pr on wi.project_id = pr.id')
                      ->join('left join oa_cst_pj_plan_phases as ph on wi.project_id = ph.project_id and wi.phases = ph.phases')
                      ->where($mm) 
                      ->page($pageindex, $pagesize)
                      ->select();  
        $this ->ajaxReturn($service);
      }elseif ($type == 4) {
        # code...
      }elseif ($type == 5) {
        # code...
      }elseif ($type == 6) {
        # code...
      }elseif ($type == 7) {
        $num = intval(date("m",time()));
        $jj1 = sprintf("%02d", $num+1);
        $y = date("Y",time());
        $sss1 = $y.'-01-01 00:00:00';
        $dds1 = $y.'-'.$jj1.'-01 00:00:00';
        $dtmap['de.del_date'] = array('between',array($sss1,$dds1),'AND');
        $data = M('cst_dev_delivery as de')
                        ->field('de.delivery_code,de.delivery_type,pr.project_name,de.del_date,de.deliver_product,de.dev_role,de.tech_role,cus.eEnd_time,cus.End_time,cus.Need_time')
                        ->join('left join oa_cst_cti_project as pr on pr.id = de.project_id')
                        ->join('left join oa_cst_dev_customization as cus on de.contract_code and de.project_id = cus.project_id')
                        ->where($dtmap)
                        ->order('del_date desc')
                        ->page($pageindex, $pagesize)
                        ->select(); 
        foreach ($data as $keyd => $valued) {
            if($valued['delivery_type'] == '1'){
              $data[$keyd]['delivery_type'] = '需求新增';
            }elseif ($valued['delivery_type'] == '2') {
              $data[$keyd]['delivery_type'] = 'bug修复';
            }elseif ($valued['delivery_type'] == '3') {
              $data[$keyd]['delivery_type'] = '首次交付';
            }
        }   
        $this ->ajaxReturn($data); 
      }

    }

}
