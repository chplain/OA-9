<?php
// +----------------------------------------------------------------------
// | Author: chenlei <714753756@qq.com>
// +----------------------------------------------------------------------

namespace Admin\Controller;
// use User\Api\UserApi as UserApi;

/**
 * 后台OA控制器
 * @author chenlei <714753756@qq.com>
 */

/*项目管理*/
class ProjectController extends AdminController {

    /*项目列表首页*/
    public function index(){
      // $data['project_type'] = "购物中心";
      // $map['project_type'] = '1';
      // $project = M("cst_cti_project as cp") ->where($map) ->save($data);
      // die();
      $pageindex['p'] = $_GET["p"];
      if (empty($pageindex['p'])||$pageindex['p']=="0") {
          $pageindex['p']=1;
      }
      $pagesize = PAGESIZE;
     
      if(isset($_GET['project_name']) ){
          $map['cp.project_name']   =   array('like', '%'.$_GET['project_name'].'%');
      }
      if(isset($_GET['customer']) ){
          $map['oc.customer']   =   array('like', '%'.$_GET['customer'].'%');
      }
      if(isset($_GET['province']) ){
          $map['cp.province']   =   array('like', '%'.$_GET['province'].'%');
      }
      if(isset($_GET['project_type']) ){
          $map['cp.project_type']   =  $_GET['project_name'];
      }
      
      if(isset($_GET['status'])){
          $map['cp.status']  =   $_GET['status'];
          $pageindex['status']=$_GET['status'];
      }else{
          $map['cp.status']  =   array('in', '0,1,2,3');
      }
    
      
      $project = M("cst_cti_project as cp")
                    ->field('cp.*,oc.customer as cus,mem.nickname as cre,mem1.nickname as upone')
                    ->join('left join oa_cst_customer as oc on cp.customer = oc.id')
                    // ->join('left join oa_member as me on me.uid = cp.charge_person')
                    ->join('left join oa_member as mem on mem.uid = cp.creator')
                    ->join('left join oa_member as mem1 on mem1.uid = cp.update_one')
                    ->where($map)
                    ->order('cp.update_time desc,cp.create_time desc,cp.begin_time desc')
                    ->page($pageindex['p'], $pagesize)
                    ->select();
      foreach ($project as $key6 => $value6) {
        $project[$key6]['budget'] = number_format ($value6['budget'] , 2 , '.' , ',' );
      }
      $this->assign('project',$project);
      // var_dump(M()->getLastSql());
      $count=M("cst_cti_project as cp")
              ->join('left join oa_cst_customer as oc on cp.customer = oc.id')
              ->where($map)
              ->count();

      if($count > $pagesize) {
          $page = new \COM\Page($count, $pagesize,$pageindex);
          $page->setConfig('theme','%FIRST% %UP_PAGE% %LINK_PAGE% %DOWN_PAGE% %END% %HEADER%');
          $this->assign('_page', $page->show());
      }
      // var_dump($count);
      // var_dump(M()->getLastSql());
      $this->display();
    }

    /*项目添加*/
    public function add(){
        if(IS_POST){
            $maxid = M("cst_cti_project")
                    ->field('id')
                    ->order('id desc')
                    ->find();
            $data['project_code'] = "PJ".sprintf("%06d", $maxid['id']+1);//生成4位数，不足前面补0   
            $data['project_name'] = I('project_name');
            $mmm['project_name'] = I('project_name');
            $res1 = M("cst_cti_project")->where($mmm)->find();
            // var_dump($res1);
            // die();
            if($res1){
              $this->error('添加失败！该项目|商业名称已存在，不能重复添加！');
            }
            $data['project_type'] = I('project_type');
            $data['customer'] = I('customer');
            $data['province'] = I('province').'-'.I('city');
            $data['purchase_intention'] = implode(",", I('purchase_intention'));
            $data['charge_person'] = I('charge_person');
            $data['creator'] = UID;
            $data['create_time'] = date("Y-m-d H:i:s",time());
            $data['last_time'] = date("Y-m-d H:i:s",time());
            $data['budget'] = I('budget');
            if(I('begin_time')){
              $data['begin_time'] = I('begin_time');
            }
            if(I('begin_time')){
              $data['open_time'] = I('open_time');
            }
            $data['discrebe'] = I('discrebe');
            $data['remark'] = I('remark');
            $data['linkman'] = I('linkman');
            $data['linkphone'] = I('linkphone');
            $res = M("cst_cti_project")->add($data);
            // var_dump(I());
            // die();
            if(!$res){
                $this->error('添加失败！');
            }else {
                $this->success('添加成功！',U('index'));
            }
        } else {
            /*获取客服列表*/
            $map['status'] = '1';
            $customers = M('cst_customer')->field('id,customer') ->where($map)->select();
            $this->assign('customers',$customers);

            /*获取商务负责人*/
            $map1['ac.group_id'] = array('in','4,7');
            $charge_persons = M('member as me')
                    ->field('me.uid,me.nickname')
                    ->join('left join oa_auth_group_access as ac on ac.uid=me.uid')
                    ->where($map1)
                    ->select();
            $this->assign('charge_persons',$charge_persons);
            // var_dump($charge_persons);
            // var_dump(M()->getLastSql());
            /*获取产品列表*/
            $products = M('cst_product as me')
                    ->field('id,product_name')
                    ->select();
            $this->assign('products',$products);
            $this->display();
        }

    }

    /*终止项目*/
    public function delete(){
     
      $status = I('request.status');
      $idArray = array_unique((array)I('ids'));
      
      $map['id'] = array('in', $idArray);

      if($status == '-1'){
        $data['status'] = '3';
        $res = M("cst_cti_project")->where($map)->save($data);
        // var_dump(M()->getLastSql());
        if(!$res){
            $this->error('终止失败！');
        } else {
            $this->success('终止成功！',U('index'));
        }
      }elseif($status == '-2'){
        $data['status'] = '1';
        $res = M("cst_cti_project")->where($map)->save($data);
        // var_dump(M()->getLastSql());
        if(!$res){
            $this->error('恢复失败！');
        } else {
            $this->success('恢复成功！',U('index'));
        }
      }elseif($status == '-3'){
        $data['status'] = '1';
        $res = M("cst_cti_project")->where($map)->save($data);
        // var_dump(M()->getLastSql());
        if(!$res){
            $this->error('确认失败！');
        } else {
            $this->success('确认成功！',U('index'));
        }
      }
    }

    /*项目更新*/
    public function updata(){
        // $data['product_code'] = 0001;
        $data['project_name'] = I('project_name');
        $data['project_type'] = I('project_type');
        $data['customer'] = I('customer');
        $data['province'] = I('province').'-'.I('city');
        $data['purchase_intention'] = implode(",", I('purchase_intention'));
        $data['charge_person'] = I('charge_person');
        $data['budget'] = I('budget');
        $data['begin_time'] = date("Y-m-d H:i:s",I('begin_time'));
        $data['discrebe'] = I('discrebe');
        $data['update_one'] = I('update_one');
        $data['update_time'] = I('update_time');

        $map['id'] = I('id');
        $res = M("cst_cti_project")->where($map)->add($data);

    }


    /*项目跟踪记录列表*/
    public function tail_list(){
        $mmmp['uid'] = UID;
        $group_id = M('auth_group_access') ->field('group_id') ->where($mmmp) ->find();
        // var_dump($group_id);
        $this ->assign('group_id',$group_id);
        if(IS_POST){
          // var_dump(I());
          $map['id'] = I('id');
          $data['purchase_intention'] = implode(',',I('purchase_intention'));
          $data['budget'] = I('budget');
          $data['linkman'] = I('linkman');
          $data['linkphone'] = I('linkphone');

          if(I('begin_time')){
            $data['begin_time'] = I('begin_time');
          }
          if(I('begin_time')){
            $data['open_time'] = I('open_time');
          }
          
          $data['charge_person'] = I('charge_person');
          $data['remark'] = I('remark');
          $data['update_one'] = UID;
          $data['update_time'] = date("Y-m-d H:i:s",time());
          $res = M('cst_cti_project as pr')  ->where($map) ->save($data);
          // var_dump(M()->getLastSql());
          // die();
          if($res){
            $this->success('更新成功！',U('tail_list',array('id'=>I('id'))));
          }else{
            $this->error('更新失败！');
          }


        }else{
          $map1['pr.id'] = I('id');
          $project = M('cst_cti_project as pr') 
                          ->field('pr.id,pr.linkphone,pr.linkman,pr.open_time,pr.project_code,pr.project_name,pr.project_type,pr.status,pr.province,pr.purchase_intention,pr.budget,pr.begin_time,pr.end_time,cu.customer,pr.remark,pr.charge_person')
                          ->join('left join  oa_cst_customer as cu on pr.customer = cu.id')
                          // ->join('left join oa_member as me on me.uid = pr.charge_person')
                          ->where($map1)
                          ->find();
          // var_dump(M()->getLastSql());
          // var_dump($project);
          $this->assign('project',$project);
          $map['ta.project_id'] = I('id');
          $tails = M("cst_cti_project_tail as ta")
                      ->field('ta.*,me.nickname')
                      ->join('left join oa_member as me on me.uid = ta.tail_person')
                      ->where($map)
                      ->order('ta.follow_up_time desc')
                      ->select();
          $this->assign('tails',$tails);
          // var_dump($tails);
          // var_dump(M()->getLastSql());
          
          // $count=M("cst_cti_project_tail as cp")
          //        ->where($map)
          //       ->count();

          // if($count > $pagesize) {
          //     $page = new \COM\Page($count, $pagesize,$pageindex);
          //     $page->setConfig('theme','%FIRST% %UP_PAGE% %LINK_PAGE% %DOWN_PAGE% %END% %HEADER%/project_id/'.I('id').'');
          //     $this->assign('_page', $page->show());
          // }
          // var_dump($page->show());
          
          /*获取产品列表*/
          $products = M('cst_product as me')
                  ->field('id,product_name')
                  ->select();
          $this->assign('products',$products);
          // var_dump($products);
          $this->display();
        }
        
    }


    /*项目跟踪记录添加*/
    public function tail_add(){

          if(IS_POST){
                $data['project_id'] = I('project_id');
                $data['intent_product'] = implode(",", I('intent_product'));
                $data['budget'] = I('budget');
                // $data['charge_person'] = I('charge_person');
                // $data['tail_person'] = UID;
                $data['discribe'] = I('discribe');
                $data['fee'] = I('fee');
                $data['follow_up_time'] = date("Y-m-d H:i:s",time());
                $data['tail_person'] = UID;
                $res = M("cst_cti_project_tail")->add($data);

                $map['id'] = I('project_id');
                $data1['update_one'] = UID;
                $data1['update_time'] = date("Y-m-d H:i:s",time());
                $res1 = M('cst_cti_project')  ->where($map) ->save($data1);
              if(!$res){
                  $this->error('添加失败！');
              } else {
                  $this->success('添加成功！',U('tail_list',array('id'=>I('project_id'))));
              }
          } else {
              // var_dump(I('id'));
              $map1['pr.id'] = I('project_id');
              // var_dump($map1);
              $project = M('cst_cti_project as pr') 
                                  ->field('pr.*')
                                  // ->join('left join oa_member as me on me.uid = pr.charge_person')
                                  ->where($map1) 
                                  ->find();
              // var_dump(M()->getLastSql());
              // var_dump($project);
              $this->assign('project',$project);

              /*拉去产品列表*/
              $mm['status'] = '1';
              $products = M('cst_product') 
                                  ->field('id,product_name')
                                  // ->join('left join oa_member as me on me.uid = pr.charge_person')
                                  ->where($mm) 
                                  ->select();
              // var_dump(M()->getLastSql());
              // var_dump($products);
              $this->assign('products',$products);

              $this->display();
        }

    }

    /*项目跟踪记录删除*/
    public function tail_delete(){
        // var_dump(I('ids'););
        // die();
        /*获取删除合同数组*/
        $data1 = I('ids')['id'];
        $data2 = I('ids')['project_id'];
        // var_dump($data1);
        // var_dump($data2);
        // die();
        $idArray = array_unique($data1);
        // $uidArray = array(4);
        $map['id'] = array('in', $idArray);

        $res = M("cst_cti_project_tail")->where($map)->delete();
        // var_dump(M()->getLastSql());
        if(!$res){
            $this->error('删除失败！');
        } else {
            $this->success('删除成功！',U('tail_list',array('id'=>$data2)));
        }
    }

}
